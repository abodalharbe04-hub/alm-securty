# ALM SEC - Render Version

هذه النسخة جاهزة للنشر على Render كرابط عام يعمل من Chrome والجوال.

## قبل الرفع
لا تضع TOKEN داخل الملفات.

## المتغيرات المطلوبة في Render
TOKEN = Discord bot token
GUILD_ID = Server ID
LOG_CHANNEL_ID = Log channel ID
ADMIN_PASSWORD = Password for the web dashboard
SESSION_SECRET = random long secret (Render can generate it)

## خطوات Render
1. أنشئ حساب في Render.
2. ارفع هذا المشروع إلى GitHub.
3. في Render اختر New > Blueprint أو Web Service.
4. اربط مستودع GitHub.
5. إذا استخدمت Blueprint سيقرأ render.yaml تلقائيًا.
6. أضف القيم السرية المطلوبة.
7. Deploy.

بعد النشر سيظهر رابط مثل:
https://alm-sec.onrender.com

## Discord Developer Portal
فعّل:
- Server Members Intent
- Message Content Intent

واعط البوت الصلاحيات اللازمة للحماية، واجعل رتبة البوت أعلى من الرتب التي تريد تطبيق الإجراءات عليها.

## ملاحظة مهمة
خطة الاستضافة المجانية قد تدخل في وضع السكون حسب سياسة Render الحالية. للبوت 24/7 استخدم خطة لا تنام أو VPS.
